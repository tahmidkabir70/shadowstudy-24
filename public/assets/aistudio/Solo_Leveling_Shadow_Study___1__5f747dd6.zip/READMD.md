# Shadow Study - The Hunter's Path

A Solo Leveling-inspired Study RPG built for SSC students. 
This app tracks real-world study activities, awards XP, and helps build consistency without using any exam or test features.

## Technologies Used
- HTML5
- CSS3 (Vanilla)
- JavaScript (Vanilla)
- LocalStorage (For saving data offline)
- Service Worker (For PWA/Offline Support)

## How to Install on Android
1. Open `index.html` in Google Chrome.
2. Create your Hunter profile.
3. Tap the three dots (menu) in Chrome and select **"Add to Home Screen"**.
4. The app will now work offline like a native app.

## File Structure
- `css/`: All styling (Solo Leveling Dark Theme)
- `js/`: All logic (XP, Quests, Timers, UI)
- `icons/`: App icons (icon.svg)

## Rules
- No in-app exams, tests, or MCQ systems.
- XP is awarded only for real study actions (Timer, Quests, Habits).
- All data is stored locally on the device. No server is used.