// v2: bumping this name forces phones to drop the old cached files
const CACHE_NAME = 'shadow-study-v2';

const ASSETS_TO_CACHE = [
  './', './index.html', './manifest.json', './icons/icon.svg',
  './dashboard.html', './quests.html', './character.html', './subjects.html',
  './study-session.html', './archive.html', './notes.html', './note-editor.html',
  './habits.html', './planner.html', './skills.html', './achievements.html',
  './statistics.html', './calendar.html', './focus.html', './settings.html',
  './system.html', './config.html',
  './css/style.css', './css/dashboard.css', './css/quests.css', './css/skills.css', './css/responsive.css',
  './js/utils.js', './js/storage.js', './js/state.js', './js/progression.js', './js/ui.js',
  './js/quest.js', './js/habits.js', './js/timer.js', './js/planner.js', './js/skills.js',
  './js/achievements.js', './js/archive.js', './js/notes.js', './js/analytics.js',
  './js/focus.js', './js/calender.js', './js/page-init.js', './js/app.js', './js/router.js',
  './fonts/Rajdhani-Medium.ttf', './fonts/Rajdhani-Bold.ttf', './fonts/ShareTechMono-Regular.ttf',
  './fonts/HindSiliguri-Regular.ttf', './fonts/HindSiliguri-SemiBold.ttf'
];

// Install: cache every file separately, so one missing file (e.g. a font not added yet) never breaks the install
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      Promise.all(ASSETS_TO_CACHE.map((url) => cache.add(url).catch(() => {})))
    )
  );
  self.skipWaiting();
});

// Activate: delete old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(names.map((n) => (n !== CACHE_NAME ? caches.delete(n) : null)))
    )
  );
  self.clients.claim();
});

// Fetch: network first (new code shows up right away), cache as the offline fallback
self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  event.respondWith(
    fetch(req)
      .then((res) => {
        if (res && res.ok && new URL(req.url).origin === self.location.origin) {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((c) => c.put(req, copy));
        }
        return res;
      })
      .catch(() =>
        caches.match(req, { ignoreSearch: true }).then((m) => m || caches.match('./index.html'))
      )
  );
});
