const State = {
  data: null,

  init: () => {
    const d = (State.data = Storage.load());

    // Migration: make sure every field exists
    d.profile = Object.assign({ name: '', rank: 'E', level: 1, xp: 0, statPoints: 0 }, d.profile || {});
    d.profile.stats = Object.assign({ str: 5, int: 5, agi: 5, vit: 5, sense: 5 }, d.profile.stats || {});
    ['quests', 'subjects', 'habits', 'activityLog'].forEach((k) => {
      if (!Array.isArray(d[k])) d[k] = [];
    });

    // xpClaims = permanent ledger of XP already paid out (the anti-cheat source of truth)
    if (!d.xpClaims || typeof d.xpClaims !== 'object') {
      d.xpClaims = {};
      const todayStr = new Date().toDateString();
      d.activityLog.forEach((l) => {
        const a = String(l.action || '');
        if (a.startsWith('Quest: ')) {
          const q = d.quests.find((x) => 'Quest: ' + x.title === a);
          if (q) d.xpClaims['q:' + q.id] = l.timestamp;
        } else if (a.startsWith('Habit: ') && new Date(l.timestamp).toDateString() === todayStr) {
          const h = d.habits.find((x) => 'Habit: ' + x.title === a);
          if (h) d.xpClaims['h:' + h.id + ':' + Utils.today()] = l.timestamp;
        }
      });
      State.save();
    }
  },

  save: () => { Storage.save(State.data); },

  addLog: (action, xp = 0) => {
    State.data.activityLog.push({
      id: Utils.generateId('log'),
      action: action,
      xp: xp,
      timestamp: Utils.getTodayISO()
    });
    State.save();
  }
};

window.State = State;
