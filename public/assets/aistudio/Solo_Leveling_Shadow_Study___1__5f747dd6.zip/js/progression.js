const Progression = {
  getXpForNextLevel: (level) => level * 100,

  calculateRank: (level) => {
    if (level >= 76) return 'S';
    if (level >= 51) return 'A';
    if (level >= 31) return 'B';
    if (level >= 16) return 'C';
    if (level >= 6) return 'D';
    return 'E';
  },

  // The ONLY way to pay XP for a repeatable action.
  // Each key (e.g. "h:HABITID:2026-10-21" or "q:QUESTID") can pay out exactly once, ever.
  claim: (key, amount, reason) => {
    const claims = State.data.xpClaims;
    if (claims[key]) return false;
    claims[key] = Utils.getTodayISO();
    Progression.addXp(amount, reason);
    return true;
  },

  addXp: (amount, reason) => {
    const p = State.data.profile;
    const oldLevel = p.level;
    const oldRank = p.rank;

    p.xp += amount;
    let need = Progression.getXpForNextLevel(p.level);
    while (p.xp >= need) {
      p.xp -= need;
      p.level++;
      need = Progression.getXpForNextLevel(p.level);
    }
    p.rank = Progression.calculateRank(p.level);

    const gained = p.level - oldLevel;
    if (gained > 0) p.statPoints = (p.statPoints || 0) + gained * 3;

    State.addLog(reason, amount); // also saves

    if (window.UI) {
      UI.updateHeader();
      if (gained > 0) UI.levelUp(oldLevel, p.level, oldRank, p.rank);
    }
    return gained;
  }
};

window.Progression = Progression;
