const ArchiveSystem = {
    addItem: (title, content) => {
        if (!State.data.archive) State.data.archive = [];
        State.data.archive.push({
            id: Utils.generateId('arc'), title: title, content: content,
            nextRevision: null, createdAt: Utils.getTodayISO()
        });
        State.save();
    },
    
    deleteItem: (id) => {
        if (!State.data.archive) return;
        State.data.archive = State.data.archive.filter(item => item.id !== id);
        State.save();
    },

    scheduleRevision: (id) => {
        const item = State.data.archive.find(i => i.id === id);
        if (!item) return;
        
        const nextDate = new Date();
        nextDate.setDate(nextDate.getDate() + 3);
        item.nextRevision = nextDate.toISOString();
        State.save();
        if(window.UI) UI.systemAlert(`Revision Scheduled.\n\nItem: ${item.title}\nDate: 3 days from now.`);
    }
};