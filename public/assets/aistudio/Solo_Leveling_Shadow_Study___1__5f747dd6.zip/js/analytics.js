const AnalyticsSystem = {
  _sessions: () => (State.data && State.data.sessions) || [],

  _ymd: (d) => {
    const p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  },

  // Real minutes from the study timer
  getTotalStudyMinutes: () => AnalyticsSystem._sessions().reduce((s, x) => s + x.minutes, 0),

  getTodayMinutes: () => {
    const t = Utils.today();
    return AnalyticsSystem._sessions().filter((x) => x.date === t).reduce((s, x) => s + x.minutes, 0);
  },

  getQuestStats: () => {
    const quests = State.data.quests || [];
    const completed = quests.filter((q) => q.completed).length;
    const total = quests.length;
    return { completed, total, percent: total > 0 ? (completed / total) * 100 : 0 };
  },

  // [{ name, minutes }] sorted high to low
  getSubjectMinutes: () => {
    const map = {};
    AnalyticsSystem._sessions().forEach((x) => { map[x.subject] = (map[x.subject] || 0) + x.minutes; });
    return Object.keys(map).map((name) => ({ name, minutes: map[name] })).sort((a, b) => b.minutes - a.minutes);
  },

  // Last n days, oldest first: [{ date, label, minutes }]
  getLastDays: (n = 7) => {
    const out = [];
    for (let i = n - 1; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = AnalyticsSystem._ymd(d);
      out.push({
        date: key,
        label: d.toLocaleDateString('en-US', { weekday: 'short' }),
        minutes: AnalyticsSystem._sessions().filter((x) => x.date === key).reduce((s, x) => s + x.minutes, 0)
      });
    }
    return out;
  },

  getHabitChecks: () => (State.data.habits || []).reduce((s, h) => s + Object.keys(h.history || {}).length, 0),

  getTotalXp: () => (State.data.activityLog || []).reduce((s, l) => s + (l.xp || 0), 0)
};

window.AnalyticsSystem = AnalyticsSystem;
