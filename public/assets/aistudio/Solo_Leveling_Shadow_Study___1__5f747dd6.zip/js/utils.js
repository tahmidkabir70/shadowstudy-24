const Utils = {
  generateId: (prefix = 'id') =>
    `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,

  // Full timestamp (used for logs)
  getTodayISO: () => new Date().toISOString(),

  // Local calendar day (YYYY-MM-DD), resets at local midnight.
  // Clock guard: if the phone date is moved backwards, we keep using the latest day ever seen,
  // so a locked habit cannot be reopened by changing the date.
  today: () => {
    const d = new Date();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const now = `${d.getFullYear()}-${m}-${day}`;
    try {
      const seen = localStorage.getItem('ss_maxday');
      if (seen && seen > now) return seen;
      localStorage.setItem('ss_maxday', now);
    } catch (e) { /* storage unavailable: fall back to the plain date */ }
    return now;
  }
};

window.Utils = Utils;
