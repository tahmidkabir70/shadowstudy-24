const PlannerSystem = {
  addTask: (title, date) => {
    if (!Array.isArray(State.data.planner)) State.data.planner = [];
    State.data.planner.push({ id: Utils.generateId('task'), title: title, date: date, completed: false });
    State.save();
  },

  // One tap completes the task and LOCKS it forever (XP once per task).
  toggleTask: (id) => {
    const task = (State.data.planner || []).find((t) => t.id === id);
    if (!task) return false;
    if (task.completed) {
      if (window.UI) UI.toast('LOCKED', 'A completed task cannot be reverted.', 'info');
      return false;
    }
    task.completed = true;
    State.save();
    Progression.reward(`p:${id}`, 5, `Planner Task: ${task.title}`, 'TASK COMPLETE', task.title);
    return true;
  },

  deleteTask: (id) => {
    if (!State.data.planner) return;
    State.data.planner = State.data.planner.filter((t) => t.id !== id);
    State.save();
  }
};

window.PlannerSystem = PlannerSystem;
