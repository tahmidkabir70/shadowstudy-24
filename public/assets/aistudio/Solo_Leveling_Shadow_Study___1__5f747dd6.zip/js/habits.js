const HabitsSystem = {
  addHabit: (title) => {
    title = String(title || '').trim();
    if (!title) return false;
    State.data.habits.push({
      id: Utils.generateId('hab'),
      title: title,
      history: {},
      createdAt: Utils.today()
    });
    State.save();
    if (window.UI) UI.refreshHabits();
    return true;
  },

  isDoneToday: (habit) => !!(habit.history && habit.history[Utils.today()]),

  // One tap completes the habit for today and LOCKS it. There is no uncheck.
  // It unlocks by itself when the next day starts.
  toggleHabit: (id) => {
    const habit = State.data.habits.find((h) => h.id === id);
    if (!habit) return;
    if (!habit.history) habit.history = {};

    const today = Utils.today();

    if (habit.history[today]) {
      if (window.UI) UI.toast('LOCKED', 'This habit is already completed today.\nIt unlocks at midnight.', 'info');
      return;
    }

    habit.history[today] = true;
    State.save();
    if (window.UI) UI.markFresh(id);

    // Second safety layer: a permanent ledger key per habit per day
    const paid = Progression.claim(`h:${id}:${today}`, 2, `Habit: ${habit.title}`);
    if (window.UI) {
      if (paid) UI.toast('HABIT MAINTAINED', `${habit.title}\n+2 XP`, 'reward');
      else UI.toast('HABIT MAINTAINED', "Today's XP for this habit was already claimed.", 'info');
      UI.refreshHabits();
      UI.updateHeader();
    }
  }
};

window.HabitsSystem = HabitsSystem;
