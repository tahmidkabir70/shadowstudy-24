const DB_KEY = 'shadow_study_db_v1';

const defaultData = {
  version: "1.0.0",
  profile: { name: "", rank: "E", level: 1, xp: 0 },
  quests: [],
  subjects: [],
  activityLog: []
};

const Storage = {
  load: () => {
    try {
      const data = localStorage.getItem(DB_KEY);
      return data ? JSON.parse(data) : JSON.parse(JSON.stringify(defaultData));
    } catch (e) {
      console.error("Storage Error:", e);
      return JSON.parse(JSON.stringify(defaultData));
    }
  },
  save: (data) => {
    try {
      localStorage.setItem(DB_KEY, JSON.stringify(data));
      return true;
    } catch (e) {
      alert("ডাটা সেভ করা যাচ্ছে না! স্টোরেজ ফুল হতে পারে।");
      return false;
    }
  }
};