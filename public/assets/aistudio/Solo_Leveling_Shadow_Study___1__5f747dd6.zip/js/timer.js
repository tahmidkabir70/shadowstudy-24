// Study timer. State lives in localStorage, so leaving the page does not lose the session.
const TIMER_KEY = 'ss_timer';

const Timer = {
  _iv: null,

  _get: () => { try { return JSON.parse(localStorage.getItem(TIMER_KEY)); } catch (e) { return null; } },
  _set: (s) => {
    try {
      if (s) localStorage.setItem(TIMER_KEY, JSON.stringify(s));
      else localStorage.removeItem(TIMER_KEY);
    } catch (e) { /* ignore */ }
  },

  elapsed: () => {
    const s = Timer._get();
    if (!s) return 0;
    return s.acc + (s.running ? Math.floor((Date.now() - s.startedAt) / 1000) : 0);
  },

  initUI: () => {
    const sel = document.getElementById('subject-select');
    if (sel) {
      sel.innerHTML = '';
      const general = document.createElement('option');
      general.value = '';
      general.textContent = 'General Study';
      sel.appendChild(general);
      (State.data.subjects || []).forEach((s) => {
        const o = document.createElement('option');
        o.value = s.id;
        o.textContent = s.title;
        sel.appendChild(o);
      });
      const cur = Timer._get();
      if (cur) sel.value = cur.subjectId || '';
    }
    Timer._render();
    const cur = Timer._get();
    if (cur && cur.running) Timer._tick();
  },

  _tick: () => {
    clearInterval(Timer._iv);
    Timer._iv = setInterval(() => Timer.updateDisplay(), 1000);
  },

  start: () => {
    let s = Timer._get();
    if (s && s.running) return;
    const sel = document.getElementById('subject-select');
    if (!s) s = { acc: 0, subjectId: sel ? sel.value : '' };
    s.running = true;
    s.startedAt = Date.now();
    Timer._set(s);
    Timer._tick();
    Timer._render();
    if (window.UI) UI.sfx('alert');
  },

  pause: () => {
    const s = Timer._get();
    if (!s || !s.running) return;
    s.acc = Timer.elapsed();
    s.running = false;
    s.startedAt = null;
    Timer._set(s);
    clearInterval(Timer._iv);
    Timer._render();
  },

  finish: () => {
    const secs = Timer.elapsed();
    const s = Timer._get();
    clearInterval(Timer._iv);
    Timer._set(null);

    const minutes = Math.floor(secs / 60);
    if (minutes < 1) {
      UI.toast('SESSION TOO SHORT', 'Less than 1 minute. Nothing was logged.', 'info');
    } else {
      const sub = (State.data.subjects || []).find((x) => s && x.id === s.subjectId);
      const rec = {
        id: Utils.generateId('ses'), date: Utils.today(), minutes: minutes,
        subjectId: sub ? sub.id : '', subject: sub ? sub.title : 'General Study', at: Utils.getTodayISO()
      };
      if (!Array.isArray(State.data.sessions)) State.data.sessions = [];
      State.data.sessions.push(rec);
      State.save();

      if (minutes >= 15) {
        Progression.reward('s:' + rec.id, 5, `Study Session: ${minutes} mins`, 'SESSION COMPLETE',
          `${rec.subject}\n${minutes} minutes`, { cap: false });
      } else {
        UI.toast('SESSION LOGGED', `${minutes} minutes logged.\nMinimum 15 minutes is required for XP.`, 'info');
      }
    }
    Timer._render();
  },

  _render: () => {
    const s = Timer._get();
    const running = !!(s && s.running);
    const active = !!s;
    const $ = (id) => document.getElementById(id);
    if ($('btn-start')) { $('btn-start').style.display = running ? 'none' : 'inline-flex'; $('btn-start').textContent = active ? 'Resume' : 'Start'; }
    if ($('btn-pause')) $('btn-pause').style.display = running ? 'inline-flex' : 'none';
    if ($('btn-finish')) $('btn-finish').style.display = active ? 'inline-flex' : 'none';
    if ($('subject-select')) $('subject-select').disabled = active;
    Timer.updateDisplay();
  },

  updateDisplay: () => {
    const e = Timer.elapsed();
    const pad = (n) => String(n).padStart(2, '0');
    const el = document.getElementById('timer-display');
    if (el) el.textContent = `${pad(Math.floor(e / 3600))}:${pad(Math.floor((e % 3600) / 60))}:${pad(e % 60)}`;
  }
};

window.Timer = Timer;
