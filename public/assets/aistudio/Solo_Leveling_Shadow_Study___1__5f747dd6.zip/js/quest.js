const QuestSystem = {
  addQuest: (title, xpReward = 10) => {
    title = String(title || '').trim();
    if (!title) return false;
    State.data.quests.push({
      id: Utils.generateId('q'),
      title: title,
      xpReward: Number(xpReward) || 10,
      completed: false,
      completedAt: null
    });
    State.save();
    if (window.UI) UI.refreshQuests();
    return true;
  },

  // One tap completes the quest and LOCKS it permanently. There is no uncheck.
  toggleQuest: (id) => {
    const quest = State.data.quests.find((q) => q.id === id);
    if (!quest) return;

    if (quest.completed) {
      if (window.UI) UI.toast('LOCKED', 'A completed quest cannot be reverted.', 'info');
      return;
    }

    quest.completed = true;
    quest.completedAt = Utils.getTodayISO();
    State.save();
    if (window.UI) UI.markFresh(id);

    // Second safety layer: a permanent ledger key per quest ID
    const paid = Progression.claim(`q:${id}`, quest.xpReward, `Quest: ${quest.title}`);
    if (window.UI) {
      if (paid) UI.toast('QUEST COMPLETE', `${quest.title}\n+${quest.xpReward} XP`, 'reward');
      else UI.toast('QUEST COMPLETE', 'XP for this quest was already claimed.', 'info');
      UI.refreshQuests();
      UI.updateHeader();
    }
  }
};

window.QuestSystem = QuestSystem;
