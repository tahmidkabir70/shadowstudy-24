const FocusSystem = {
  _iv: null,
  _lock: null,
  
  start: () => {
    if (document.getElementById('focus-overlay')) return;
    const start = Date.now();
    const o = h('div');
    o.id = 'focus-overlay';
    const q = h('div', 'focus-quote', '"I alone level up."');
    const t = h('div', 'focus-time', '00:00');
    const hint = h('div', 'tag', 'Deep focus. Phone down. Study.');
    const b = h('button', 'btn btn-danger', 'Exit Focus');
    b.addEventListener('click', FocusSystem.end);
    o.append(q, t, hint, b);
    document.body.appendChild(o);
    
    const pad = (n) => String(n).padStart(2, '0');
    FocusSystem._iv = setInterval(() => {
      const s = Math.floor((Date.now() - start) / 1000);
      t.textContent = `${pad(Math.floor(s / 60))}:${pad(s % 60)}`;
    }, 1000);
    
    try { if (navigator.wakeLock) navigator.wakeLock.request('screen').then((l) => { FocusSystem._lock = l; }).catch(() => {}); } catch (e) {}
    try { if (document.documentElement.requestFullscreen) document.documentElement.requestFullscreen().catch(() => {}); } catch (e) {}
    if (window.UI) UI.sfx('alert');
  },
  
  end: () => {
    clearInterval(FocusSystem._iv);
    const o = document.getElementById('focus-overlay');
    if (o) o.remove();
    try { if (FocusSystem._lock) { FocusSystem._lock.release();
        FocusSystem._lock = null; } } catch (e) {}
    try { if (document.fullscreenElement) document.exitFullscreen(); } catch (e) {}
  }
};

window.FocusSystem = FocusSystem;