const AchievementSystem = {
  metrics: () => ({
    quests: (State.data.quests || []).filter((q) => q.completed).length,
    xp: (State.data.activityLog || []).reduce((s, l) => s + (l.xp || 0), 0),
    level: State.data.profile.level,
    sessions: (State.data.sessions || []).length,
    minutes: (State.data.sessions || []).reduce((s, x) => s + x.minutes, 0),
    checks: (State.data.habits || []).reduce((s, h) => s + Object.keys(h.history || {}).length, 0)
  }),

  list: [
    { id: 'first_quest', code: 'Q1', title: 'First Quest Completed', desc: 'Complete 1 quest.', test: (m) => m.quests >= 1 },
    { id: 'quests_10', code: 'Q10', title: 'Quest Clearer', desc: 'Complete 10 quests.', test: (m) => m.quests >= 10 },
    { id: 'xp_100', code: 'XP', title: '100 XP Club', desc: 'Earn 100 total XP.', test: (m) => m.xp >= 100 },
    { id: 'level_5', code: 'L5', title: 'Reached Level 5', desc: 'Reach Level 5.', test: (m) => m.level >= 5 },
    { id: 'level_10', code: 'L10', title: 'Reached Level 10', desc: 'Reach Level 10.', test: (m) => m.level >= 10 },
    { id: 'first_session', code: 'T1', title: 'First Training', desc: 'Log your first study session.', test: (m) => m.sessions >= 1 },
    { id: 'study_5h', code: 'T5', title: 'Five Hours Strong', desc: 'Study 300 minutes in total.', test: (m) => m.minutes >= 300 },
    { id: 'habit_10', code: 'H10', title: 'Habit Builder', desc: 'Complete 10 habit check-ins.', test: (m) => m.checks >= 10 }
  ],

  check: () => {
    if (!Array.isArray(State.data.unlockedAchievements)) State.data.unlockedAchievements = [];
    const m = AchievementSystem.metrics();
    AchievementSystem.list.forEach((a) => {
      if (State.data.unlockedAchievements.includes(a.id) || !a.test(m)) return;
      State.data.unlockedAchievements.push(a.id);
      State.save();
      Progression.reward('a:' + a.id, 10, `Achievement: ${a.title}`, 'ACHIEVEMENT UNLOCKED', a.title, { cap: false });
    });
  }
};

window.AchievementSystem = AchievementSystem;
