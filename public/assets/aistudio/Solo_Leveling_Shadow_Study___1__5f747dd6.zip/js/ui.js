const UI = {
  _ctx: null,
  _timers: {},
  _fresh: {},

  /* ---------- Sound + vibration (Web Audio, no files needed) ---------- */
  sfx: (kind) => {
    try {
      if (localStorage.getItem('ss_sound') === 'off') return;
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) {
        UI._ctx = UI._ctx || new AC();
        const c = UI._ctx;
        if (c.state === 'suspended') c.resume();
        const seqs = {
          alert: [[880, 0, 0.09], [1320, 0.09, 0.14]],
          done: [[660, 0, 0.08], [990, 0.08, 0.12]],
          undo: [[440, 0, 0.08]],
          levelup: [[523, 0, 0.14], [659, 0.14, 0.14], [784, 0.28, 0.14], [1047, 0.42, 0.55]]
        };
        (seqs[kind] || []).forEach(([freq, delay, dur]) => {
          const o = c.createOscillator();
          const g = c.createGain();
          const t = c.currentTime + delay;
          o.type = kind === 'levelup' ? 'triangle' : 'sine';
          o.frequency.value = freq;
          g.gain.setValueAtTime(0.0001, t);
          g.gain.exponentialRampToValueAtTime(0.12, t + 0.02);
          g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
          o.connect(g);
          g.connect(c.destination);
          o.start(t);
          o.stop(t + dur + 0.03);
        });
      }
      if (navigator.vibrate) navigator.vibrate(kind === 'levelup' ? [80, 60, 160] : 25);
    } catch (e) { /* sound is optional */ }
  },

  /* ---------- Notification that slides in from the top (non-blocking) ---------- */
  toast: (title, msg = '', type = 'info') => {
    let box = document.getElementById('sys-toasts');
    if (!box) {
      box = document.createElement('div');
      box.id = 'sys-toasts';
      document.body.appendChild(box);
    }
    while (box.children.length >= 3) box.firstChild.remove();

    const t = document.createElement('div');
    t.className = `sys-toast ${type}`;
    const h = document.createElement('div');
    h.className = 'sys-toast-title';
    h.textContent = `[!] ${title}`;
    const m = document.createElement('div');
    m.className = 'sys-toast-msg';
    m.textContent = msg;
    t.append(h, m);
    box.appendChild(t);

    requestAnimationFrame(() => requestAnimationFrame(() => t.classList.add('show')));
    UI.sfx(type === 'reward' ? 'done' : 'alert');

    const close = () => {
      t.classList.remove('show');
      setTimeout(() => t.remove(), 450);
    };
    t.addEventListener('click', close);
    setTimeout(close, 3800);
  },

  // Backward compatible: old code (timer.js etc.) calls this
  systemAlert: (message) => UI.toast('SYSTEM', String(message).trim(), 'info'),

  /* ---------- Global Level-Up / Rank-Up overlay ---------- */
  levelUp: (oldLevel, newLevel, oldRank, newRank) => {
    const old = document.getElementById('lvl-overlay');
    if (old) old.remove();
    const rankUp = oldRank !== newRank;

    const o = document.createElement('div');
    o.id = 'lvl-overlay';
    o.innerHTML = `
      <div class="lvl-beams"></div>
      <div class="lvl-box">
        <div class="lvl-tag">[ SYSTEM ]</div>
        <div class="lvl-title">${rankUp ? 'RANK UP' : 'LEVEL UP'}</div>
        <div class="lvl-num" id="lvl-num">${oldLevel}</div>
        <div class="lvl-sub">${rankUp ? `Rank ${oldRank} → <b>${newRank}</b>` : `Rank <b>${newRank}</b>`}</div>
        ${rankUp ? '<div class="lvl-arise">ARISE.</div>' : ''}
        <div class="lvl-pts">+${(newLevel - oldLevel) * 3} STAT POINTS</div>
        <div class="lvl-hint" id="lvl-hint">&nbsp;</div>
      </div>`;
    document.body.appendChild(o);
    document.body.classList.add('no-scroll');
    requestAnimationFrame(() => requestAnimationFrame(() => o.classList.add('show')));
    UI.sfx('levelup');

    // Count the level number up
    const num = o.querySelector('#lvl-num');
    let cur = oldLevel;
    const step = () => {
      if (cur < newLevel) {
        cur++;
        num.textContent = cur;
        setTimeout(step, Math.max(70, 700 / (newLevel - oldLevel)));
      }
    };
    setTimeout(step, 800);

    // The UI is "paused" for a moment before it can be dismissed
    let ready = false;
    setTimeout(() => {
      ready = true;
      const hint = o.querySelector('#lvl-hint');
      if (hint) hint.textContent = 'TAP TO CONTINUE';
    }, 2000);

    o.addEventListener('click', () => {
      if (!ready) return;
      o.classList.remove('show');
      document.body.classList.remove('no-scroll');
      setTimeout(() => o.remove(), 600);
      UI.updateHeader();
    });
  },

  /* ---------- Header ---------- */
  updateHeader: () => {
    const p = State.data && State.data.profile;
    if (!p || !p.name) return;
    const need = Progression.getXpForNextLevel(p.level);
    const percent = Math.max(0, Math.min(100, (p.xp / need) * 100));
    const set = (id, fn) => { const el = document.getElementById(id); if (el) fn(el); };

    set('hunter-name', (el) => { el.innerText = p.name; });
    set('hunter-rank', (el) => { el.innerText = p.rank; el.dataset.rank = p.rank; });
    set('hunter-level', (el) => { el.innerText = `Lv. ${p.level}`; });
    set('xp-bar', (el) => { el.style.width = `${percent}%`; });
    set('xp-text', (el) => { el.innerText = `${p.xp} / ${need} XP`; });
    set('header-avatar', (el) => { el.innerText = p.name.charAt(0).toUpperCase(); });
  },

  /* ---------- Flicker-free list rendering (cards are updated in place) ---------- */
  markFresh: (id) => { UI._fresh[id] = Date.now() + 5000; },
  unmark: (id) => { delete UI._fresh[id]; clearTimeout(UI._timers[id]); },

  _card: (item, reward, onToggle) => {
    const el = document.createElement('div');
    el.className = 'quest-card';
    el.dataset.id = item.id;

    const body = document.createElement('div');
    const title = document.createElement('div');
    title.className = 'quest-title';
    title.textContent = item.title;
    const rw = document.createElement('div');
    rw.className = 'quest-rewards';
    rw.textContent = `+${reward} XP`;
    body.append(title, rw);

    const cb = document.createElement('div');
    cb.className = 'quest-checkbox';
    cb.setAttribute('role', 'checkbox');
    cb.addEventListener('click', () => onToggle(item.id));

    el.append(body, cb);
    return el;
  },

  _apply: (el, done) => {
    const id = el.dataset.id;
    const cb = el.querySelector('.quest-checkbox');
    clearTimeout(UI._timers[id]);

    el.classList.toggle('is-done', done);
    cb.classList.toggle('checked', done);
    cb.textContent = done ? '✓' : '';
    cb.setAttribute('aria-checked', done ? 'true' : 'false');

    if (!done) {
      delete UI._fresh[id];
      el.classList.remove('collapsed');
      return;
    }
    const left = (UI._fresh[id] || 0) - Date.now();
    if (left > 0) {
      // Just completed: stay visible, then glide away after the remaining time
      el.classList.remove('collapsed');
      UI._timers[id] = setTimeout(() => {
        el.classList.add('collapsed');
        delete UI._fresh[id];
        UI._syncDone(el.parentNode);
      }, left);
    } else {
      el.classList.add('collapsed');
    }
  },

  _syncDone: (list) => {
    if (!list || !list.id) return;
    const n = list.querySelectorAll('.quest-card.is-done').length;
    let btn = document.getElementById('done-toggle-' + list.id);
    if (!n) { if (btn) btn.remove(); return; }
    if (!btn) {
      btn = document.createElement('button');
      btn.id = 'done-toggle-' + list.id;
      btn.className = 'done-toggle';
      btn.addEventListener('click', () => {
        document.body.classList.toggle('show-done');
        UI._syncDone(list);
      });
      list.after(btn);
    }
    const open = document.body.classList.contains('show-done');
    btn.textContent = `${open ? '▲ HIDE' : '▼ SHOW'} COMPLETED (${n})`;
  },

  _sync: (list, items, isDone, reward, onToggle, emptyMsg) => {
    if (!items.length) {
      list.innerHTML = '';
      const p = document.createElement('p');
      p.className = 'empty-msg';
      p.textContent = emptyMsg;
      list.appendChild(p);
      UI._syncDone(list);
      return;
    }
    const ids = new Set(items.map((i) => i.id));
    Array.from(list.children).forEach((c) => {
      if (!c.dataset.id || !ids.has(c.dataset.id)) c.remove();
    });
    items.forEach((it) => {
      let el = list.querySelector(`[data-id="${CSS.escape(it.id)}"]`);
      if (!el) {
        el = UI._card(it, reward(it), onToggle);
        list.appendChild(el);
      }
      UI._apply(el, isDone(it));
    });
    UI._syncDone(list);
  },

  refreshQuests: () => {
    const list = document.getElementById('quest-list');
    if (!list) return;
    UI._sync(
      list, State.data.quests,
      (q) => !!q.completed,
      (q) => q.xpReward,
      (id) => QuestSystem.toggleQuest(id),
      'কোনো কুয়েস্ট নেই। নতুন যোগ করুন!'
    );
  },

  refreshHabits: () => {
    const list = document.getElementById('habits-list');
    if (!list) return;
    const today = Utils.today();
    UI._sync(
      list, State.data.habits,
      (h) => !!(h.history && h.history[today]),
      () => 2,
      (id) => HabitsSystem.toggleHabit(id),
      'কোনো অভ্যাস নেই।'
    );
  }
};

window.UI = UI;
