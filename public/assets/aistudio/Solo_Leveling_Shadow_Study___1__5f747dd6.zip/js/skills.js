// Skills are calculated from your real activity, so they can never be farmed or edited by tapping.
const SkillSystem = {
  init: () => {},

  _minutesWhere: (re) => (State.data.sessions || [])
    .filter((s) => re.test(s.subject || ''))
    .reduce((sum, s) => sum + s.minutes, 0),

  compute: () => {
    const total = (State.data.sessions || []).reduce((s, x) => s + x.minutes, 0);
    const checks = (State.data.habits || []).reduce((s, h) => s + Object.keys(h.history || {}).length, 0);
    const math = SkillSystem._minutesWhere(/math|গণিত|ম্যাথ/i);
    const sci = SkillSystem._minutesWhere(/science|physics|chem|bio|বিজ্ঞান|পদার্থ|রসায়ন|জীব/i);
    const mem = (State.data.archive || []).length + (State.data.notes || []).length;

    const defs = [
      { code: 'FOC', name: 'Focus', value: total, per: 60, unit: 'min studied' },
      { code: 'CON', name: 'Consistency', value: checks, per: 7, unit: 'habit check-ins' },
      { code: 'MAT', name: 'Mathematics', value: math, per: 60, unit: 'min in math subjects' },
      { code: 'SCI', name: 'Science', value: sci, per: 60, unit: 'min in science subjects' },
      { code: 'MEM', name: 'Memory', value: mem, per: 5, unit: 'archive + notes' }
    ];
    return defs.map((d) => ({
      code: d.code, name: d.name, unit: d.unit, value: d.value, per: d.per,
      level: 1 + Math.floor(d.value / d.per),
      pct: Math.round(((d.value % d.per) / d.per) * 100),
      next: d.per - (d.value % d.per)
    }));
  }
};

window.SkillSystem = SkillSystem;
