// এটি গ্লোবাল ইনিশিয়ালাইজেশন হ্যান্ডেল করে
const PageInit = {
  init: () => {
    if (window.State) State.init();
    if (window.UI) UI.updateHeader();
    if (window.AchievementSystem) AchievementSystem.check();
  }
};