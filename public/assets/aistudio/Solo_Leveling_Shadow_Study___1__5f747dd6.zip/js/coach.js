// Rule-based local System messages. No network, no AI.

import { state, STARTER, ATTRIBUTES } from './state.js';
import { dstr } from './utils.js';
import { countAttr } from './progression.js';
import { displayStreak } from './quests.js';

export function buildCoach() {
  const out = [];
  const today = dstr();
  const incomplete = state.quests.filter((q) => !q.completed);
  const overdue = incomplete.filter((q) => q.deadline && q.deadline < today);
  
  if (overdue.length) {
    out.push({
      id: 'overdue',
      icon: '⚠',
      title: overdue.length + ' overdue quest' + (overdue.length > 1 ? 's' : ''),
      text: 'The System has detected failed deadlines. Reschedule or break the quest into a smaller step. Failure is data.',
      actions: overdue.slice(0, 3).map((q) => ({
        label: 'Reschedule: ' + q.title,
        action: 'reschedule',
        qid: q.id
      }))
    });
  }
  
  if (state.quests.length === 0) {
    out.push({
      id: 'start',
      icon: '◈',
      title: 'System initialization',
      text: 'No active quests detected. Accept a starter quest to begin your ascent.',
      actions: STARTER.slice(0, 4).map((s, i) => ({
        label: '+ ' + s.title,
        action: 'add-suggested',
        idx: i
      }))
    });
  }
  
  if (incomplete.length > 8) {
    out.push({
      id: 'overload',
      icon: '🧘',
      title: 'Quest load critical',
      text: 'You currently have ' + incomplete.length + ' open quests. Keep only 3 priorities. The rest can wait.',
      actions: [{ label: 'Open Quest Log', action: 'nav', view: 'quests' }]
    });
  }
  
  const st = displayStreak();
  if (!st.alive && state.streak.lastDate) {
    out.push({
      id: 'recovery',
      icon: '💙',
      title: 'Welcome back, Hunter',
      text: 'A missed day does not erase your progress. Accept one easy quest to restart the streak. Best streak is preserved.',
      actions: [{ label: '+ Easy reset quest', action: 'add-recovery' }]
    });
  }
  
  if (state.focusSessions.length === 0) {
    out.push({
      id: 'focus',
      icon: '⏱',
      title: 'Focus protocol available',
      text: 'One 25-minute session builds momentum. Breaks are part of the plan.',
      actions: [{ label: 'Open Focus Timer', action: 'open-timer' }]
    });
  }
  
  const empty = ATTRIBUTES.filter((a) => countAttr(a) === 0);
  if (empty.length && state.history.length >= 3) {
    out.push({
      id: 'balance',
      icon: '⚖',
      title: 'Attribute imbalance detected',
      text: 'No progress yet in: ' + empty.join(', ') + '. Issue one small quest for balance.',
      actions: empty.slice(0, 2).map((a) => ({
        label: '+ Quest for ' + a,
        action: 'add-attr',
        attr: a
      }))
    });
  }
  
  if (state.history.length > 0) {
    const last = state.history[state.history.length - 1];
    out.push({
      id: 'next',
      icon: '→',
      title: 'Next recommended step',
      text: 'You completed "' + last.title + '". Review it or repeat it tomorrow as a Daily Quest.',
      actions: [{
        label: '+ Repeat as Daily',
        action: 'add-repeat',
        title: last.title,
        attr: last.attribute
      }]
    });
  }
  
  if (!out.length) {
    out.push({
      id: 'ok',
      icon: '✓',
      title: 'System status: stable',
      text: 'Continue at your own pace. Consider issuing one quest that advances a long-term goal.',
      actions: [{ label: 'New Quest', action: 'new-quest' }]
    });
  }
  
  return out;
}