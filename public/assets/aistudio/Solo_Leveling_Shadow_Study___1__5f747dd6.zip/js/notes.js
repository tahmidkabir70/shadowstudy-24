const NotesSystem = {
  addNote: (title, content) => {
    if (!Array.isArray(State.data.notes)) State.data.notes = [];
    State.data.notes.push({ id: Utils.generateId('note'), title: title, content: content, createdAt: Utils.getTodayISO() });
    State.save();
  },

  updateNote: (id, title, content) => {
    const n = (State.data.notes || []).find((x) => x.id === id);
    if (!n) return false;
    n.title = title;
    n.content = content;
    n.updatedAt = Utils.getTodayISO();
    State.save();
    return true;
  },

  deleteNote: (id) => {
    if (!State.data.notes) return;
    State.data.notes = State.data.notes.filter((n) => n.id !== id);
    State.save();
  }
};

window.NotesSystem = NotesSystem;
