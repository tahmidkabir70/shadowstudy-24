// Shared page shell: theme meta, manifest, header, bottom nav, service worker.
// Load this AFTER utils/storage/state/progression/ui and BEFORE the page's own script.
(function () {
  const head = document.head;
  const body = document.body;

  if (!document.querySelector('meta[name="theme-color"]')) {
    const m = document.createElement('meta');
    m.name = 'theme-color';
    m.content = '#03050a';
    head.appendChild(m);
  }
  if (!document.querySelector('link[rel="manifest"]')) {
    const l = document.createElement('link');
    l.rel = 'manifest';
    l.href = 'manifest.json';
    head.appendChild(l);
  }
  const vp = document.querySelector('meta[name="viewport"]');
  if (vp && vp.content.indexOf('viewport-fit') === -1) vp.content += ', viewport-fit=cover';

  // Tiny DOM helper: h('div', 'class', 'text'). Text is always set safely (no HTML injection).
  window.h = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined && text !== null) e.textContent = text;
    return e;
  };

  if (window.State && !State.data) State.init();
  if (window.State && State.data && !State.data.profile.name) {
    location.replace('index.html');
    return;
  }

  if (!document.querySelector('.top-header')) {
    const hd = h('div', 'top-header');
    hd.appendChild(h('h2', '', body.dataset.title || 'Shadow Study'));
    const r = h('div', 'hud-label');
    const rank = h('span', '', 'E');
    rank.id = 'hunter-rank';
    rank.dataset.rank = 'E';
    const lv = h('span', '', 'Lv. 1');
    lv.id = 'hunter-level';
    r.append(rank, ' // ', lv);
    hd.appendChild(r);
    body.insertBefore(hd, body.firstChild);
  }

  if (!document.querySelector('.bottom-nav')) {
    const items = [
      ['dashboard', '🏠', 'Home'], ['quests', '📜', 'Quests'], ['habits', '🔥', 'Habits'],
      ['character', '👤', 'Status'], ['settings', '⚙️', 'System']
    ];
    const nav = h('div', 'bottom-nav');
    items.forEach(([key, icon, label]) => {
      const a = h('a', 'nav-item' + (body.dataset.nav === key ? ' active' : ''));
      a.href = key + '.html';
      a.append(h('span', 'nav-icon', icon), ' ' + label);
      nav.appendChild(a);
    });
    body.appendChild(nav);
  }

  if (window.UI && window.State && State.data) UI.updateHeader();
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});
})();
